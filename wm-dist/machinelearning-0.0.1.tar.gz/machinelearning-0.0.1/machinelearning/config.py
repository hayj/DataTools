
import numpy as np

MASK_TOKEN = "__m_a_s_k__"
OOV_TOKEN = "__o_o_v__"
MASK_EMBEDDING_FUNCTION = np.zeros
OOV_EMBEDDING_FUNCTION = np.ones